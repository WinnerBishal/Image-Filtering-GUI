"""
The following program delivers an interactive GUI where different image filters can be applied to an 
image by only clicking buttons.
Available Filters:
1. 5x5 Triangle Filter
2. 5x5 Gaussian Filter with user-specified sigma value
3. 5x5 Median Filter
4. 5x5 Kuwahara Filter
 Additional features include an option to update the source image with the recently applied filter
which allows testing multiple filters consequently. Revert to original option is added which will
reset the image by removing all filters.

To run the program in python, two aditional libraries OpenCV and Pillow are needed and can be installed 
as instructed in the sites:
OpenCV : https://pypi.org/project/opencv-python/
Pillow : https://pillow.readthedocs.io/en/stable/installation.html 

**Note**: These libraries are only used for GUI and image reading purpose. All the filtering implementations
are done from scratch without using external libraries.

Shortcomings: Median Filter and Kuwahara Filter are slow.  
Also, the program can run with a single image at a time. To try filters with different images, filename of the
image can be changed in line #33 of this file. The image file should be in the same directory as this file.

"""
import cv2
import matplotlib.pyplot as plt
import numpy as np
import math
from tkinter import *
from PIL import ImageTk, Image

image_filename = "vegetables.png"

def triangle_kernel(n):
    arr = np.arange(n)
    raw = (n + 1)/2 - (np.abs(arr - arr[::-1])) / 2
    kernel = np.outer(raw, raw)
 
    return kernel/kernel.sum()

def closest_pixel_padder(inn, k):
    #initialize padded array
    padded = np.zeros(((inn.shape[0]+ 2*k), (inn.shape[1] + 2*k)))
    
    #replace central part of padded array with original image
    padded[k:-k, k:-k] = inn
    
    x = inn.shape[0]
    y = inn.shape[1]
    
    # middle top two rows
    padded[0, k:-k] = inn[0, :]
    padded[1, k:-k] = inn[0, :]
    # middle left two rows
    padded[k:-k, 0] = inn[:, 0]
    padded[k:-k, 1] = inn[:, 0]
    # middle bottom two rows
    padded[y+k, k:-k] = inn[y-1, :]
    padded[y+2*k-1, k:-k] = inn[y-1, :]
    # middle right two rows
    padded[k:-k, x+k] = inn[:, x-1]
    padded[k:-k, x+2*k-1] = inn[:, x-1]
    # corner values
    padded[0:k+1, 0:k+1] = inn[0,0]
    padded[-(k+1):, 0: k+1] = inn[x-1,0]
    padded[0:k+1, y+1:] = inn[0,y-1]
    padded[-(k+1):, -(k+1):] = inn[x-1, y-1]
    
    return padded

def convolution(image, kernel, k):
    x = image.shape[0]
    y = image.shape[1]
    
    padded_img = closest_pixel_padder(image, k)
    out_img = np.zeros((x, y))
    for i in range(k, x+k):
        for j in range(k, y+k):
            mask = padded_img[i-k:(i+k)+1, j-k:(j+k)+1]
            out_img[i-k, j-k] = (kernel*mask).sum()
    return out_img

def filter_image(cv2_image, kernel, k):
    kernel = np.flipud(kernel)
    kernel = np.fliplr(kernel)
    
    red = cv2_image[:,:,0]
    green = cv2_image[:,:,1]
    blue = cv2_image[:,:,2]
    
    red_out = convolution(red, kernel, k)
    green_out = convolution(green, kernel, k)
    blue_out = convolution(blue, kernel, k)
    
    img1 = []
    for i in range(len(cv2_image)):
        rgb = []
        for j in range(len(cv2_image)):
            rgb.append([red_out[i,j], green_out[i,j], blue_out[i,j]])
        img1.append([rgb])
    img2 = np.array(img1).reshape(cv2_image.shape[0], cv2_image.shape[1], 3).clip(0,255).astype('uint8')
    
    return img2

def add_noise(img):
    i, j, n = img.shape
    mean = 0
    std = 40
    gaussian_arr = np.random.normal(mean, std, (i, j, n))
    img_result = img + gaussian_arr
    
    return img_result.clip(0,255).astype(np.uint8)

def gaussian_kernel(n, sigma):
    kernel = np.zeros((n,n))
    for i in range(n):
        for j in range(n):
            exp_pow = (i** + j**2) / (2*sigma**2)
            num = math.exp(-1 * exp_pow)
            den = 2*math.pi*sigma*sigma 
            kernel[i,j] = num/den
    return kernel

def median_filter_2D(image, k):
    x = image.shape[0]
    y = image.shape[1]
    
    padded_img = closest_pixel_padder(image, k)
    out_img = np.zeros((x, y))
    for i in range(k, x+k):
        for j in range(k, y+k):
            mask = padded_img[i-k:(i+k)+1, j-k:(j+k)+1]
            out_img[i-k, j-k] = np.median(sorted(mask.reshape((2*k +1)**2,)))
    return out_img

def median_filter_rgb(cv2_image, k):
    
    red = cv2_image[:,:,0]
    green = cv2_image[:,:,1]
    blue = cv2_image[:,:,2]
    
    red_out = median_filter_2D(red, k)
    green_out = median_filter_2D(green, k)
    blue_out = median_filter_2D(blue, k)
    
    img1 = []
    for i in range(len(cv2_image)):
        rgb = []
        for j in range(len(cv2_image)):
            rgb.append([red_out[i,j], green_out[i,j], blue_out[i,j]])
        img1.append([rgb])
    img2 = np.array(img1).reshape(cv2_image.shape[0], cv2_image.shape[1], 3).clip(0,255).astype('uint8')
    
    return img2

def kuwahara_filter_2D(image, k):
    x = image.shape[0]
    y = image.shape[1]
    
    padded_img = closest_pixel_padder(image, k)
    out_img = np.zeros((x, y))
    for i in range(k, x+k):
        for j in range(k, y+k):
            mask = padded_img[i-k:(i+k)+1, j-k:(j+k)+1]
            
            a = mask.shape[0]
            b = mask.shape[1]
            
            mr = int((a - 1)/2)
            mc = int((b - 1)/2)
            
            m1 = mask[0:(mr+1), 0:(mc+1)]
            m2 = mask[0:(mr+1), mc:]
            m3 = mask[mr:, 0:(mc+1)]
            m4 = mask[mr:, mc:]
            m = [m1, m2, m3, m4]
            m_var = [np.var(m1), np.var(m2), np.var(m3), np.var(m4)]
            
            out_img[i-k, j-k] = np.mean(m[m_var.index(min(m_var))])
            
    return out_img

def kuwahara_filter_rgb(cv2_image, k):
    
    red = cv2_image[:,:,0]
    green = cv2_image[:,:,1]
    blue = cv2_image[:,:,2]
    
    red_out = kuwahara_filter_2D(red, k)
    green_out = kuwahara_filter_2D(green, k)
    blue_out = kuwahara_filter_2D(blue, k)
    
    img1 = []
    for i in range(len(cv2_image)):
        rgb = []
        for j in range(len(cv2_image)):
            rgb.append([red_out[i,j], green_out[i,j], blue_out[i,j]])
        img1.append([rgb])
    img2 = np.array(img1).reshape(cv2_image.shape[0], cv2_image.shape[1], 3).clip(0,255).astype('uint8')
    
    return img2


# GUI Implementations:

def show_noise(img):
    noisy = add_noise(initial_image).clip(0,255).astype(np.uint8)
    
    tk_img = ImageTk.PhotoImage(Image.fromarray(noisy))
    
    result.configure(image = tk_img)
    result.image = tk_img
    global current_result 
    current_result = noisy
    
def show_tri(img):
    tri_img = filter_image(initial_image, triangle_kernel(5), 2)
    
    tk_img = ImageTk.PhotoImage(Image.fromarray(tri_img))
    
    result.configure(image = tk_img)
    result.image = tk_img
    global current_result
    current_result = tri_img

def show_gauss(img, sigma):
    gauss_img = filter_image(initial_image, gaussian_kernel(5, sigma), 2)
    
    tk_img = ImageTk.PhotoImage(Image.fromarray(gauss_img))
    
    result.configure(image = tk_img)
    result.image = tk_img
    global current_result
    current_result = gauss_img

def show_median(img):
    median_img = median_filter_rgb(initial_image, 2)
    
    tk_img = ImageTk.PhotoImage(Image.fromarray(median_img))
    
    result.configure(image = tk_img)
    result.image = tk_img
    global current_result
    current_result = median_img
    
def show_kuwa(img):
    kuwa_img = kuwahara_filter_rgb(initial_image, 2)
    
    tk_img = ImageTk.PhotoImage(Image.fromarray(kuwa_img))
    
    result.configure(image = tk_img)
    result.image = tk_img
    global current_result
    current_result = kuwa_img
    
def update_source():
    global current_result
    global initial_image
    initial_image = current_result
    tk_image = ImageTk.PhotoImage(Image.fromarray(current_result))
    
    source.configure(image = tk_image)
    source.image = tk_image

def revert():
    global initial_image
    initial_image = cv2.imread(image_filename)
    initial_image = cv2.cvtColor(initial_image, cv2.COLOR_BGR2RGB)
    
    tk_image = ImageTk.PhotoImage(Image.fromarray(initial_image))
    
    source.configure(image = tk_image)
    source.image = tk_image
    
    result.configure(image = tk_image)
    result.image = tk_image

#GUI Implementation

initial_image = cv2.imread(image_filename)
initial_image = cv2.cvtColor(initial_image, cv2.COLOR_BGR2RGB)
current_result = initial_image

root = Tk()
root.title("Smoothing Filters")
entry1 = Entry(root, width = 5, borderwidth = 2)

label1 = Label(root, text = "Sigma :")

title1 = Label(root, text = "Source Image")
title2 = Label(root, text = "Result Image")

baboon = ImageTk.PhotoImage(Image.fromarray(initial_image))
source = Label(root, image = baboon, borderwidth = 5)

result = Label(root, image = baboon, borderwidth = 5)

button1 = Button(root, text = "Add Noise", command =lambda: show_noise(initial_image))
button2 = Button(root, text = "5x5 Triangle", command = lambda:show_tri(initial_image))
button3 = Button(root, text = "5x5 Gussian", command = lambda:show_gauss(initial_image, float(entry1.get())))
button4 = Button(root, text = "5x5 Median", command = lambda:show_median(initial_image))
button5 = Button(root, text = "5x5 Kuwahara", command = lambda:show_kuwa(initial_image))
button6 = Button(root, text = "Update Source", command = lambda:update_source())
button7 = Button(root, text = "Revert to Original", command = lambda:revert())

title1.grid(row = 0, column = 0, columnspan = 4)
title2.grid(row = 0, column = 4, columnspan = 4)

source.grid(row = 1, column = 0, columnspan = 4)
result.grid(row = 1, column = 4, columnspan = 4)

button1.grid(row = 2, column = 0)
button2.grid(row = 2, column = 1)

label1.grid(row = 2, column = 2)
entry1.grid(row = 2, column = 3)

button3.grid(row = 2, column = 4)
button4.grid(row = 2, column = 5)
button5.grid(row = 2, column = 6)
button6.grid(row = 2, column = 7)
button7.grid(row = 3, column = 7)

root.mainloop()